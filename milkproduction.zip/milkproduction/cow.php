<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>User Information</title>
</head>
<body>
    <header>
        <h1>User Information about Cow</h1>
        <nav>
            <ul>
                <li><a href="login.html">Login</a></li>
                <li><a href="register.html">Register</a></li>
                <li><a href="milk_sell.php">Sell Milk</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <h2>All User Information</h2>
        <?php
        // Assuming you have a database connection
        $conn = mysqli_connect("localhost", "root", "", "milk_production");

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Assuming you have a table called 'user_information' with fields: name, animal, fat, rate, liter
        $sql = "SELECT * FROM milk WHERE animal='Cow'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo "<table border='1'>";
            echo "<tr><th>Name</th><th>Animal</th><th>Fat</th><th>Rate</th><th>Liter</th></tr>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>{$row['name']}</td><td>{$row['animal']}</td><td>{$row['fat']}</td><td>{$row['rate']}</td><td>{$row['liter']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found.";
        }

        mysqli_close($conn);
        ?>
    </section>
</body>
</html>
