<?php
// Get the user's input from the form
$name = $_POST['name'];
$animal=$_POST['animal'];
$fat=$_POST['fat'];
$rate=$_POST['rate'];
$milkAmount = $_POST['milk_amount'];


$mysqli = new mysqli("localhost", "root", "", "milk_production");


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Insert user data into the database
$query = "INSERT INTO milk (name,animal,fat, rate,liter) VALUES ('$name','$animal','$fat','$rate', '$milkAmount')";

if ($mysqli->query($query) === TRUE) {
    echo "Milk sale recorded successfully.";
} else {
    echo "Error: " . $query . "<br>" . $mysqli->error;
}

$mysqli->close();
?>
