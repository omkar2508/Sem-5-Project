<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Sell Milk</title>
    <style>
        table {
            border-collapse: collapse;
            width: 40%; /* Make the table fill the entire width */
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            width: 50%; /* Set the width of each cell to 50% */
        }
        select, input[type="text"], input[type="number"] {
            width: 100%; /* Make the input fields and dropdown fill their parent cells */
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to Shree Ganesh Dairy</h1>
        <nav>
            <!-- ... Your navigation links ... -->
        </nav>
    </header>

    <section id="sell-milk">
        <h2>Sell Milk</h2>
        <form method="POST" action="process_milk_sell.php">
            <table>
                <tr>
                    <td><label for="name">Your Name:</label></td>
                    <td><input type="text" name="name" id="name" required></td>
                </tr>
                <tr>
                    <td><label for="animal">Animal:</label></td>
                    <td>
                        <select name="animal" id="animal" required>
                          <option value="Choose animal"></option>
                            <option value="Cow">Cow</option>
                            <option value="Buffalo">Buffalo</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="fat">Fat:</label></td>
                    <td><input type="number" name="fat" id="fat" required></td>
                </tr>
                <tr>
                    <td><label for="rate">Rate of Milk (per liter):</label></td>
                    <td>
                        <select name="rate" id="rate" required>
                          <option value="Choose rate"></option>
                            <option value="100">Cow(100/-)</option>
                            <option value="80">Buffalo(80/-)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="milk-amount">Amount of Milk (in liters):</label></td>
                    <td><input type="number" name="milk_amount" id="milk-amount" required></td>
                </tr>
            </table>
            <input type="submit" value="Submit">
        </form>
    </section>

</body>
</html>
