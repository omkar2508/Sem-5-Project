<?php
// Replace with your database connection details
$mysqli = new mysqli("localhost", "root", "", "milk_prodution");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

function getTotalMilkSold($milkType) {
    global $mysqli;

    $query = "SELECT SUM(liter) AS total_sold FROM milk_selling WHERE milk_type = '$milkType'";
    $result = $mysqli->query($query);

    if ($result && $row = $result->fetch_assoc()) {
        return $row['total_sold'];
    }

    return 0;
}

$mysqli->close();
?>
